import React, { Component } from "react";

class Landing extends Component {
  render() {
    return <h1>Library Management System</h1>;
  }
}

export default Landing;
        