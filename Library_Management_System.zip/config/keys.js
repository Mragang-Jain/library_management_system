module.exports = {
  mongoURI:
    "mongodb://keshav:Keshav@12345@ds263848.mlab.com:63848/lms_keshav",
  localDBURI: "mongodb://localhost:27017/lms_keshav"
};