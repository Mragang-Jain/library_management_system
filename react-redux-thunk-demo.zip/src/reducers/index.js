import books from './books'
import selectedBook from './selectedBook'
import {combineReducers} from 'redux'

export default combineReducers({
  books,
  selectedBook,
})




